// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAQzK3B-Ps0yatA80Jb9iv3pB1f_l6NuGg",
  authDomain: "sheyshop-n.firebaseapp.com",
  projectId: "sheyshop-n",
  storageBucket: "sheyshop-n.appspot.com",
  messagingSenderId: "782581138699",
  appId: "1:782581138699:web:1a2cfbb4ec95f945178e0e",
  measurementId: "G-X5LGTKXSDP"
};

// Initialize Firebase
export const firebaseApp = initializeApp(firebaseConfig);

