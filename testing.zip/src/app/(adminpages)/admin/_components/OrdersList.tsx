import React from 'react'

function OrdersList() {
  return (
    <div>OrdersList</div>
  )
}

export default OrdersList